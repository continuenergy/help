---
name: continu-help
description: "PowerPoint how-to help for the Continu template. FIRST ACTION every time: duplicate the matching help slide from the Help library section (the slide holding the picture or video named 'HELP <topic-id>') and put the copy directly after the slide the user is on – no web lookups and no other attempts before that. Then give the numbered steps. When the user replies done, delete only the help slide you added."
---

# Continu Help (help slides)

Be fast: one quick look at the deck, one placement, one short reply. Never search the web, never download anything, never fetch the GIF from a link. Never ask questions.

## Step 1 – work out the topic
Read the request for its meaning, not exact words, using the "Also matches" words and common sense ("make the photo fit the box" = Fill or fit; "graph" = chart). Pick ONE topic from the Topics table. If none fits, pick the area (Areas table) and skip to Step 3.

## Step 2 – add the help slide next to theirs (do this first, straight away)
1. The template has a section called **Help library** at the end. It has one help slide per topic: the slide holds a picture or video named **HELP <topic-id>** (for example `HELP crop-image`), the topic title and its steps. Find the slide by that name – never by slide number.
2. **Duplicate that one help slide** and put the copy **directly after the slide the user is on**. Don't try to copy the picture on its own – go straight to duplicating the slide.
3. Change nothing on the copy, and never touch the Help library slides themselves.
4. If there's no help slide for this topic, add nothing and say: "There's no animation for this in the template yet."

## Step 3 – reply
Reply in this shape, short:

"**<Topic name>** – the animation is on the next slide (slide <n>).
1. <step> 2. <step> … (the steps from the table, numbered – don't write your own)
Reply **done** to remove it."

Then, only if it's quick, call **web.open** on the topic's Link and cite it, and add: "Or click the grey link chip for the full help page." Never mention the link chip unless you actually called web.open in this reply.

For an area with no exact topic: add no slide; call web.open on the area's Link and say "There isn't a how-to for exactly that yet – **click the grey link chip** to see all the **<Area>** help." plus 1–3 short lines of general guidance.

## Step 4 – when they reply "done" (or "remove it", "thanks, that's it")
Delete only the help slide you added – the copy of a help slide that sits outside the **Help library** section. Never delete or change anything else, and never touch the Help library slides. Reply: "Removed."

## Areas

| Area | Link | Everyday words that point here |
|---|---|---|
| Images | https://continuenergy.github.io/help/?area=Images | picture, photo, image, logo, icon, crop, cut, trim, resize, frame, placeholder, replace, swap, zoom, blurry, stretched |
| Slides | https://continuenergy.github.io/help/?area=Slides | slide, layout, background, colour scheme, dark, light, theme, design, master, reset, broken, moved, new slide, order, move slides, sections, columns |
| Text | https://continuenergy.github.io/help/?area=Text | text, words, font, typeface, size, bold, colour of words, highlight, bullet, list, spacing, line spacing, paste, copy style, overflow, too long, doesn't fit, alignment |
| Links | https://continuenergy.github.io/help/?area=Links | link, hyperlink, url, website, web address, button, jump to slide, click through, navigate |
| Tables | https://continuenergy.github.io/help/?area=Tables | table, grid, rows, columns, cells, borders, Excel table, header row, spreadsheet |
| Charts | https://continuenergy.github.io/help/?area=Charts | chart, graph, bar, column chart, pie, line chart, lines, axis, legend, data, numbers, labels, series, gridlines, plot |
| Saving | https://continuenergy.github.io/help/?area=Saving | save, template, potx, file, copy, new file, export, share, version |

## Topics (only these – never invent others)

| Area | Topic | Link | Also matches | Steps (PC) |
|---|---|---|---|---|
| Images | Crop an image | https://continuenergy.github.io/help/?topic=crop-image | trim cut picture photo | 1 Click the picture · 2 Open the Picture Format tab · 3 Click Crop (in the Size group) · 4 Drag the picture or its corners to reposition it · 5 Click Crop again, or press Esc, to finish |
| Images | Replace a picture | https://continuenergy.github.io/help/?topic=replace-picture | swap change image photo | 1 Right-click the picture · 2 Choose Change Picture → From a File… · 3 Pick your image – it keeps the same size and position |
| Images | Drag a picture in from a folder | https://continuenergy.github.io/help/?topic=drag-picture | drop finder explorer replace image photo | 1 Open the folder in File Explorer next to PowerPoint · 2 Drag the picture onto the empty picture box on the slide · 3 Let go – it drops into the frame |
| Images | Fill or fit a picture in its frame | https://continuenergy.github.io/help/?topic=fill-fit | crop resize image photo | 1 Click the picture · 2 Open the Picture Format tab · 3 Click the small arrow under Crop · 4 Choose Fill to fill the frame, or Fit to show the whole picture · 5 Click Crop to finish |
| Slides | Change the background colour | https://continuenergy.github.io/help/?topic=background-colour | background color colour dark light fill navy white theme | 1 Select the slide · 2 On the Home tab, click Layout · 3 Pick the light or dark version of the same layout – your content moves across |
| Text | Paste text without its formatting | https://continuenergy.github.io/help/?topic=paste-text | paste keep text only plain word email font wrong | 1 Copy the text from Word, email or a web page · 2 Click into the text box on the slide · 3 Right-click and choose Keep Text Only (the clipboard icon with an A) |
| Text | Copy formatting with Format Painter | https://continuenergy.github.io/help/?topic=format-painter | style match brush copy format | 1 Click inside the text that has the style you want · 2 On the Home tab, click Format Painter (the brush) · 3 Drag across the text you want to change |
| Text | Turn key words green | https://continuenergy.github.io/help/?topic=green-words | highlight colour color emphasis font | 1 Select the word or phrase · 2 On the Home tab, click the arrow next to Font Colour · 3 Choose the Continu green from Theme Colours |
| Text | Make text fit without shrinking it | https://continuenergy.github.io/help/?topic=fit-text | overflow too long shrink font size autofit | 1 Click into the text box and see where the text runs past the box · 2 Shorten the copy – aim for the same number of lines as the original · 3 Keep the font size as it is; never resize the box |
| Links | Hyperlink text | https://continuenergy.github.io/help/?topic=link-text | link url website hyperlink | 1 Select the text you want to link · 2 Right-click and choose Link (or Ctrl+K) · 3 Type or paste the web address, then click OK · 4 Click away – the text is now a link |
| Links | Hyperlink a button or image | https://continuenergy.github.io/help/?topic=link-object | link shape icon picture button url slide | 1 Click the edge of the button or image so the whole thing is selected · 2 Press Ctrl+K (or Insert → Link) · 3 Type a web address – or choose Place in This Document and pick a slide · 4 Click OK |
| Slides | Add a new slide from a layout | https://continuenergy.github.io/help/?topic=new-slide | insert new slide layout template | 1 On the Home tab, click the arrow on New Slide · 2 Pick the layout you need · 3 Click into the boxes to add your content |
| Slides | Change a slide's layout | https://continuenergy.github.io/help/?topic=change-layout | columns 3 4 5 switch layout design | 1 Select the slide · 2 On the Home tab, click Layout · 3 Pick the layout you want – e.g. 4 columns instead of 3 – your content moves into the new boxes |
| Slides | Reset a slide to its design | https://continuenergy.github.io/help/?topic=reset-slide | reset fix moved broken design | 1 Select the slide · 2 On the Home tab, click Reset · 3 Positions, sizes and text styles go back to the template – your words stay |
| Slides | Reorder slides by dragging | https://continuenergy.github.io/help/?topic=reorder-slides | move order drag drop sections | 1 In the slide thumbnails on the left, click a slide · 2 Drag it up or down to its new place · 3 Let go – drag onto a section name to move it into that section |
| Tables | Add a table | https://continuenergy.github.io/help/?topic=add-table | table grid rows columns insert | 1 Click the table icon in an empty content box – or go to Insert → Table · 2 Choose how many columns and rows you need · 3 Click into the cells and type |
| Tables | Add or delete rows and columns | https://continuenergy.github.io/help/?topic=table-rows | table row column insert delete remove | 1 Click into a cell next to where you want the change · 2 Open the table Layout tab · 3 Click Insert Above / Below / Left / Right – or Delete to remove |
| Tables | Apply the Continu table style | https://continuenergy.github.io/help/?topic=table-style | table style design colours colors header | 1 Click anywhere in the table · 2 Open the Table Design tab · 3 Pick a style from the gallery – the first row uses the Continu colours |
| Tables | Paste a table from Excel | https://continuenergy.github.io/help/?topic=paste-excel-table | excel spreadsheet paste table cells | 1 Copy the cells in Excel · 2 In PowerPoint, click on the slide and paste · 3 Click the paste icon that appears and choose Use Destination Styles · 4 Then apply a style from Table Design |
| Charts | Add a chart | https://continuenergy.github.io/help/?topic=add-chart | chart graph bar line pie insert | 1 Click the chart icon in an empty content box – or go to Insert → Chart · 2 Pick the chart type and click OK · 3 Type your numbers into the sheet that opens, then close it |
| Charts | Edit chart data | https://continuenergy.github.io/help/?topic=chart-data | chart data numbers change update graph | 1 Click the chart · 2 Open the Chart Design tab · 3 Click Edit Data, change the numbers, then close the sheet |
| Charts | Change chart colours to Continu colours | https://continuenergy.github.io/help/?topic=chart-colours | chart colours colors theme brand palette | 1 Click the chart · 2 Open the Chart Design tab · 3 Click Change Colours and pick a palette – they all use the Continu theme colours |
| Saving | Save your deck as a template | https://continuenergy.github.io/help/?topic=save-template | save potx template file copy | 1 Click File → Save As and pick a folder · 2 Under file type choose PowerPoint Template (*.potx) · 3 Name it and click Save – it appears under File → New → Personal |


Keep replies short. Say "company", never "prospect".
