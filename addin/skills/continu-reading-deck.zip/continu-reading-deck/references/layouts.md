# Continu Read master: layouts and placeholders

Positions are in points from the top-left of a 960 × 540 pt slide. Identify placeholders on a new slide by position (left, top) or by idx.

## R01: Cover  (layout name "Read | 01 Cover")
Word budget: Title ≤ 8 words, subtitle ≤ 20

| idx | placeholder | left | top | width | height |
|---|---|---|---|---|---|
| 20 | Document type | 45 | 150 | 417 | 19 |
| 0 | Title | 45 | 177 | 433 | 134 |
| 21 | Subtitle | 45 | 319 | 417 | 55 |
| 22 | Prepared for | 45 | 429 | 417 | 49 |
| 23 | Cover image | 519 | 0 | 441 | 540 |

## R02: Contents  (layout name "Read | 02 Contents")
Word budget: Up to 12 entries

| idx | placeholder | left | top | width | height |
|---|---|---|---|---|---|
| 20 | Section label | 45 | 30 | 472 | 17 |
| 0 | Title | 45 | 50 | 870 | 47 |
| 22 | Contents list | 45 | 134 | 870 | 339 |

## R03: Section opener  (layout name "Read | 03 Section opener")
Word budget: Title ≤ 5 words, intro ≤ 40

| idx | placeholder | left | top | width | height |
|---|---|---|---|---|---|
| 20 | Section number | 45 | 91 | 236 | 87 |
| 0 | Title | 45 | 189 | 504 | 110 |
| 21 | Section intro | 45 | 311 | 441 | 118 |

## R04: Two-column text  (layout name "Read | 04 Two-column text")
Word budget: ≈ 300 words (150 per column)

| idx | placeholder | left | top | width | height |
|---|---|---|---|---|---|
| 20 | Section label | 45 | 30 | 472 | 17 |
| 0 | Title | 45 | 50 | 870 | 60 |
| 21 | Standfirst | 45 | 114 | 870 | 41 |
| 30 | Body | 45 | 167 | 417 | 312 |
| 31 | Body | 498 | 167 | 417 | 312 |

## R05: Three-column text  (layout name "Read | 05 Three-column text")
Word budget: ≈ 330 words (110 per column)

| idx | placeholder | left | top | width | height |
|---|---|---|---|---|---|
| 20 | Section label | 45 | 30 | 472 | 17 |
| 0 | Title | 45 | 50 | 870 | 60 |
| 21 | Standfirst | 45 | 114 | 870 | 41 |
| 30 | Body | 45 | 167 | 266 | 312 |
| 31 | Body | 347 | 167 | 266 | 312 |
| 32 | Body | 649 | 167 | 266 | 312 |

## R06: Text with sidebar  (layout name "Read | 06 Text with sidebar")
Word budget: ≈ 240 words + sidebar facts

| idx | placeholder | left | top | width | height |
|---|---|---|---|---|---|
| 20 | Section label | 45 | 30 | 567 | 17 |
| 0 | Title | 45 | 50 | 579 | 60 |
| 21 | Standfirst | 45 | 114 | 579 | 41 |
| 30 | Body | 45 | 167 | 271 | 312 |
| 31 | Body | 352 | 167 | 271 | 312 |
| 40 | Sidebar label | 681 | 55 | 210 | 17 |
| 41 | Key figure | 681 | 83 | 210 | 55 |
| 42 | Key figure caption | 681 | 140 | 210 | 41 |
| 43 | Sidebar text | 681 | 197 | 210 | 260 |

## R07: Text with image  (layout name "Read | 07 Text with image")
Word budget: ≈ 150 words

| idx | placeholder | left | top | width | height |
|---|---|---|---|---|---|
| 20 | Section label | 45 | 30 | 425 | 17 |
| 0 | Title | 45 | 50 | 425 | 60 |
| 21 | Standfirst | 45 | 114 | 425 | 49 |
| 30 | Body | 45 | 175 | 425 | 304 |
| 31 | Image | 504 | 30 | 411 | 413 |
| 32 | Image caption | 504 | 453 | 411 | 26 |

## R08: Text with table  (layout name "Read | 08 Text with table")
Word budget: Table ≤ 8 rows × 5 columns; standfirst ≤ 30

| idx | placeholder | left | top | width | height |
|---|---|---|---|---|---|
| 20 | Section label | 45 | 30 | 472 | 17 |
| 0 | Title | 45 | 50 | 870 | 47 |
| 21 | Standfirst | 45 | 102 | 870 | 41 |
| 30 | Table | 45 | 156 | 870 | 283 |
| 31 | Table notes | 45 | 449 | 870 | 30 |

## R09: Text with chart  (layout name "Read | 09 Text with chart")
Word budget: Chart + ≤ 80 words

| idx | placeholder | left | top | width | height |
|---|---|---|---|---|---|
| 20 | Section label | 45 | 30 | 472 | 17 |
| 0 | Title | 45 | 50 | 870 | 47 |
| 30 | Chart | 45 | 126 | 535 | 353 |
| 31 | Insight label | 618 | 139 | 297 | 17 |
| 32 | Key figure | 618 | 165 | 297 | 51 |
| 33 | Insight text | 618 | 224 | 297 | 254 |

## R10: Key takeaways  (layout name "Read | 10 Key takeaways")
Word budget: 3 points: heading ≤ 6 words, text ≤ 40

| idx | placeholder | left | top | width | height |
|---|---|---|---|---|---|
| 20 | Section label | 45 | 30 | 472 | 17 |
| 0 | Title | 45 | 50 | 870 | 47 |
| 21 | Standfirst | 45 | 102 | 870 | 41 |
| 40 | Number 1 | 45 | 193 | 266 | 47 |
| 41 | Point heading 1 | 45 | 248 | 266 | 49 |
| 42 | Point text 1 | 45 | 303 | 266 | 176 |
| 43 | Number 2 | 347 | 193 | 266 | 47 |
| 44 | Point heading 2 | 347 | 248 | 266 | 49 |
| 45 | Point text 2 | 347 | 303 | 266 | 176 |
| 46 | Number 3 | 649 | 193 | 266 | 47 |
| 47 | Point heading 3 | 649 | 248 | 266 | 49 |
| 48 | Point text 3 | 649 | 303 | 266 | 176 |

## R11: Appendix  (layout name "Read | 11 Appendix")
Word budget: ≈ 600 words at 9pt

| idx | placeholder | left | top | width | height |
|---|---|---|---|---|---|
| 20 | Section label | 45 | 30 | 472 | 17 |
| 0 | Title | 45 | 50 | 870 | 41 |
| 30 | Body | 45 | 106 | 870 | 372 |

## R12: Title only  (layout name "Read | 12 Title only")
Word budget: Title only

| idx | placeholder | left | top | width | height |
|---|---|---|---|---|---|
| 20 | Section label | 45 | 30 | 472 | 17 |
| 0 | Title | 45 | 50 | 870 | 60 |
