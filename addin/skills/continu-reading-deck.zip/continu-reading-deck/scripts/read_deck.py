#!/usr/bin/env python3
"""Continu reading deck: Word document -> pages on the "Continu Read" master.

  python3 read_deck.py plan  input.docx  plan.json      # auto-plan pages (review and edit before building)
  python3 read_deck.py build plan.json  output.pptx [--template T] [--cover-image IMG]

Rules the planner follows (and the build never breaks):
  * Only layouts from the "Continu Read" master are used.
  * Text is never shrunk. When content is longer than a page holds, it moves to a
    "continued" page.
  * Columns are split at headings, balanced by estimated line count.
"""
import json, math, os, re, sys, datetime, copy
from lxml import etree

HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(HERE, '..', 'assets')

# ------------------------------------------------------------ geometry
# Usable text area per layout (points) and the lines a column holds at 11pt.
EMU_PT = 12700
COL_W = {'R04': 5295900 / EMU_PT, 'R05': 3378200 / EMU_PT, 'R06': 3446400 / EMU_PT,
         'R07': 5400000 / EMU_PT, 'R11': 3378200 / EMU_PT}
LINES = {'R04': 20, 'R05': 20, 'R06': 20, 'R07': 18, 'R11': 30}   # R11 is 9pt
SIZE = {'R11': 9}
CHAR_EM = 0.47          # average Effra character width, in ems (measured, with a margin)


def cpl(layout, indent=0):
    sz = SIZE.get(layout, 11)
    return max(10, int((COL_W[layout] - indent) / (sz * CHAR_EM)))


def item_lines(it, layout):
    k = it['k']
    if k == 'h':
        return math.ceil(len(it['t']) / cpl(layout)) + 0.25
    if k == 'p':
        return math.ceil(len(it['t']) / cpl(layout)) + 0.5
    if k == 'b':
        t = (it.get('lead', '') + ': ' if it.get('lead') else '') + it['t']
        return math.ceil(len(t) / cpl(layout, 14)) + 0.35
    return 1


def lines(items, layout):
    return sum(item_lines(i, layout) for i in items)


def words(items):
    n = 0
    for i in items:
        n += len((i.get('lead', '') + ' ' + i.get('t', '')).split())
    return n

# ------------------------------------------------------------ read the Word document
def read_docx(path):
    import docx
    from docx.table import Table
    from docx.text.paragraph import Paragraph
    d = docx.Document(path)
    out = {'title': '', 'subtitle': '', 'sections': []}
    cur = None
    body = d.element.body
    for el in body.iterchildren():
        tag = el.tag.split('}')[1]
        if tag == 'tbl':
            t = Table(el, d)
            rows = [[c.text.strip() for c in r.cells] for r in t.rows]
            if cur is None:
                cur = {'title': 'Introduction', 'items': []}; out['sections'].append(cur)
            cur['items'].append({'k': 't', 'rows': rows})
            continue
        if tag != 'p':
            continue
        p = Paragraph(el, d)
        txt = p.text.strip()
        if not txt:
            continue
        st = (p.style.name or '').lower()
        if st == 'title' and not out['title']:
            out['title'] = txt; continue
        if st.startswith('heading 1') or st == 'heading1':
            cur = {'title': re.sub(r'^\d+[.)]\s*', '', txt), 'items': []}
            out['sections'].append(cur); continue
        if cur is None and out['title'] and not out['subtitle'] and not st.startswith('heading'):
            out['subtitle'] = txt; continue
        if cur is None:
            cur = {'title': 'Introduction', 'items': []}; out['sections'].append(cur)
        if st.startswith('heading'):
            cur['items'].append({'k': 'h', 't': txt}); continue
        is_list = 'list' in st or p._p.pPr is not None and p._p.pPr.numPr is not None
        if is_list:
            lead = ''
            r0 = p.runs[0] if p.runs else None
            if r0 is not None and r0.bold and len(p.runs) > 1:
                lead = r0.text.strip().rstrip(':').strip()
                txt = ''.join(r.text for r in p.runs[1:]).strip()
            cur['items'].append({'k': 'b', 't': txt, 'lead': lead}); continue
        cur['items'].append({'k': 'p', 't': txt})
    if not out['title'] and out['sections']:
        out['title'] = out['sections'][0]['title']
    return out

# ------------------------------------------------------------ planning
def blocks_of(items):
    """Group items into blocks that start at a heading."""
    bl, cur = [], []
    for it in items:
        if it['k'] == 'h' and cur:
            bl.append(cur); cur = []
        cur.append(it)
    if cur:
        bl.append(cur)
    return bl


def pack(items, layout, ncols):
    """Split items into pages of ncols columns. Never shrinks: overflow goes to a new page."""
    cap = LINES[layout]
    pages, cols, col = [], [], []
    used = 0
    def flush_col():
        nonlocal col, used
        cols.append(col); col = []; used = 0
    for it in items:
        h = item_lines(it, layout)
        if used + h > cap and col:
            flush_col()
            if len(cols) == ncols:
                pages.append(cols)
                cols = []
        col.append(it); used += h
    if col:
        cols.append(col)
    if cols:
        pages.append(cols)
    return pages


def units_of(items):
    """Smallest movable pieces: a heading always travels with the item after it."""
    us, i = [], 0
    while i < len(items):
        if items[i]['k'] == 'h' and i + 1 < len(items):
            us.append(items[i:i + 2]); i += 2
        else:
            us.append([items[i]]); i += 1
    return us


def partition(items, layout, ncols, us=None):
    """Contiguous split into ncols columns that minimises the tallest column.
    Breaks before a heading are preferred. Returns (columns, tallest column in lines)."""
    us = us or units_of(items)
    L = [lines(u, layout) for u in us]
    n = len(us)
    pre = [0]
    for x in L:
        pre.append(pre[-1] + x)
    starts_h = [u[0]['k'] == 'h' for u in us]
    best = {}
    def f(i, k):  # units i.. into k columns -> (cost, tallest, cuts)
        if (i, k) in best:
            return best[(i, k)]
        if k == 1:
            r = (pre[n] - pre[i], pre[n] - pre[i], [])
        else:
            r = None
            for j in range(i + 1, n - k + 2):
                h = pre[j] - pre[i]
                c2, t2, cuts = f(j, k - 1)
                tall = max(h, t2)
                cost = tall + (0 if starts_h[j] else 1.5)
                if r is None or cost < r[0]:
                    r = (cost, tall, [j] + cuts)
        best[(i, k)] = r
        return r
    k = min(ncols, n)
    _, tall, cuts = f(0, k)
    idx = [0] + cuts + [n]
    cols = [sum(us[idx[c]:idx[c + 1]], []) for c in range(len(idx) - 1)]
    while len(cols) < ncols:
        cols.append([])
    return cols, tall


def fits(items, layout, ncols):
    return partition(items, layout, ncols)[1] <= LINES[layout]


def paginate(items, layout, ncols):
    """Pages of ncols columns. Pages break between headed blocks (a block only splits
    if it is too big for a page on its own). The content is then shared evenly across
    the pages so none is left almost empty."""
    us = []
    for b in blocks_of(items):
        us.extend([b] if fits(b, layout, ncols) else units_of(b))
    greedy = []; i = 0
    while i < len(us):
        j = i + 1
        while j < len(us) and fits(sum(us[i:j + 1], []), layout, ncols):
            j += 1
        greedy.append(us[i:j]); i = j
    if len(greedy) < 2:
        return [sum(g, []) for g in greedy]
    # even split over the same units: page "height" = lines at this layout / ncols
    even = [c for c in partition(items, layout, len(greedy), us)[0] if c]
    if len(even) == len(greedy) and all(fits(p, layout, ncols) for p in even):
        return even
    return [sum(g, []) for g in greedy]


def balance(items, layout, ncols):
    return partition(items, layout, ncols)[0]


def balance_old(items, layout, ncols):
    """Spread one page's items across ncols columns, breaking at headings where possible."""
    total = lines(items, layout)
    target = total / ncols
    bl = blocks_of(items)
    # if a single block is bigger than a column, break it into items
    units = []
    for b in bl:
        if lines(b, layout) > target * 1.25:
            units.extend([[i] for i in b])
        else:
            units.append(b)
    cols = [[] for _ in range(ncols)]
    k, acc = 0, 0
    for u in units:
        lu = lines(u, layout)
        if k < ncols - 1 and cols[k] and acc + lu / 2 > target * (k + 1):
            k += 1
        cols[k].extend(u); acc += lu
    # never leave a heading at the bottom of a column on its own
    for c in range(ncols - 1):
        if cols[c] and cols[c][-1]['k'] == 'h':
            cols[c + 1].insert(0, cols[c].pop())
    return cols


def plan(doc, doc_type='Document', short=None):
    short = short or doc['title']
    eb = short
    pages = [{'layout': 'R01', 'doc_type': doc_type, 'title': doc['title'], 'subtitle': doc['subtitle'],
              'prepared': f"Continu  ·  {datetime.date.today():%B %Y}"}]
    secs = doc['sections']
    if len(secs) >= 4:
        pages.append({'layout': 'R02', 'eyebrow': 'Contents', 'title': 'Contents',
                      'items': [f"{i+1:02d}   {s['title']}" for i, s in enumerate(secs)]})
    SHORT = 100
    def is_short(s):
        its = s['items']
        nb = sum(1 for x in its if x['k'] == 'h')
        return (not any(x['k'] == 't' for x in its)) and words(its) <= SHORT and nb != 3
    # group runs of short sections (2 or 3 per page, one section per column)
    groups, run = [], []
    for i, s in enumerate(secs):
        if is_short(s):
            run.append(i)
            if len(run) == 3:
                groups.append(run); run = []
        else:
            if run: groups.append(run); run = []
            groups.append([i])
    if run: groups.append(run)
    for g in groups:
        if len(g) > 1:
            nums = ' / '.join(f"{i+1:02d}" for i in g)
            titles = [secs[i]['title'] for i in g]
            t = ' and '.join(titles) if len(g) == 2 else f"{titles[0]}, {titles[1]} and {titles[2]}"
            cols = [[{'k': 'h', 't': secs[i]['title']}] + [x for x in secs[i]['items'] if x['k'] != 'h' or True]
                    for i in g]
            pages.append({'layout': 'R04' if len(g) == 2 else 'R05', 'eyebrow': f"{nums}  {eb}",
                          'title': t, 'standfirst': '', 'columns': cols, 'merged': titles})
            continue
        i = g[0]; s = secs[i]
        num = f"{i+1:02d}"
        label = f"{num}  {s['title']}  |  {eb}"
        items = list(s['items'])
        tables = [it for it in items if it['k'] == 't']
        text = [it for it in items if it['k'] != 't']
        standfirst = ''
        if text and text[0]['k'] == 'p' and len(text[0]['t'].split()) <= 45 and (len(text) > 1 or tables):
            standfirst = text.pop(0)['t']
        if tables:
            notes = ''
            if text and words(text) <= 40 and all(x['k'] == 'p' for x in text):
                notes = ' '.join(x['t'] for x in text); text = []
            for t in tables:
                pages.append({'layout': 'R08', 'eyebrow': label, 'title': s['title'], 'standfirst': standfirst,
                              'table': t['rows'], 'notes': notes})
                standfirst = ''; notes = ''
            if not text:
                continue
        if not text:
            continue
        bl = blocks_of(text)
        if len(bl) == 3 and all(b[0]['k'] == 'h' for b in bl) and \
                max(lines(b, 'R05') for b in bl) <= LINES['R05'] and not fits(text, 'R04', 2) or \
                len(bl) == 3 and all(b[0]['k'] == 'h' for b in bl) and max(lines(b, 'R05') for b in bl) <= LINES['R05'] * 0.6:
            pages.append({'layout': 'R05', 'eyebrow': label, 'title': s['title'],
                          'standfirst': standfirst, 'columns': bl})
            continue
        if fits(text, 'R04', 2):
            lay, n = 'R04', 2
            chunks = [text]
        elif fits(text, 'R05', 3):
            lay, n = 'R05', 3
            chunks = [text]
        else:
            a, b = paginate(text, 'R04', 2), paginate(text, 'R05', 3)
            lay, n, chunks = ('R04', 2, a) if len(a) <= len(b) else ('R05', 3, b)
        for j, ch in enumerate(chunks):
            pages.append({'layout': lay, 'eyebrow': label,
                          'title': s['title'] + (' (continued)' if j else ''),
                          'standfirst': standfirst if j == 0 else '',
                          'columns': balance(ch, lay, n)})
    return pages

# ------------------------------------------------------------ building
def build(pages, out, template=None, cover_image=None):
    from pptx import Presentation
    from pptx.util import Pt, Emu
    from pptx.dml.color import RGBColor
    from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
    A = '{http://schemas.openxmlformats.org/drawingml/2006/main}'
    NAVY = RGBColor(0x32, 0x4E, 0x64); GREY = RGBColor(0xE6, 0xEA, 0xE4); WHITE = RGBColor(255, 255, 255)
    prs = Presentation(template or os.path.join(ASSETS, 'Continu_Template.pptx'))
    master = [m for m in prs.slide_masters if m.element.cSld.get('name') == 'Continu Read'][0]
    LAY = {'R' + l.name.split('| ')[1][:2]: l for l in master.slide_layouts}
    orig = list(prs.slides._sldIdLst)
    made = []

    def ph(s, idx):
        for p in s.placeholders:
            if p.placeholder_format.idx == idx:
                return p
        return None

    def setp(p, paras):
        tf = p.text_frame; tf.clear(); first = True
        for it in paras:
            para = tf.paragraphs[0] if first else tf.add_paragraph(); first = False
            if isinstance(it, str):
                para.text = it; continue
            if it['k'] == 'h':
                r = para.add_run(); r.text = it['t']; r.font.name = 'Effra Medium'
                para.space_after = Pt(2)
            elif it['k'] == 'b':
                para.level = 1
                if it.get('lead'):
                    r = para.add_run(); r.text = it['lead'] + ': '; r.font.name = 'Effra Medium'
                r = para.add_run(); r.text = it['t']
            else:
                para.text = it['t']

    for pg in pages:
        lay = pg['layout']
        s = prs.slides.add_slide(LAY[lay]); made.append(s)
        used = set()
        def put(idx, val):
            p = ph(s, idx)
            if p is not None and val:
                setp(p, val if isinstance(val, list) else [val]); used.add(idx)
        if s.shapes.title is not None and pg.get('title'):
            s.shapes.title.text = pg['title']
        if lay == 'R01':
            put(20, pg.get('doc_type')); put(21, pg.get('subtitle')); put(22, pg.get('prepared'))
            img = pg.get('image') or cover_image or os.path.join(ASSETS, 'cover_default.jpg')
            p = ph(s, 23)
            if p is not None and img and os.path.exists(img):
                p.insert_picture(img); used.add(23)
        elif lay == 'R02':
            put(20, pg.get('eyebrow')); put(22, pg.get('items'))
        elif lay == 'R03':
            put(20, pg.get('number')); put(21, pg.get('intro'))
            p = ph(s, 23)
            img = pg.get('image') or os.path.join(ASSETS, 'cover_default.jpg')
            if p is not None and os.path.exists(img):
                p.insert_picture(img); used.add(23)
        else:
            put(20, pg.get('eyebrow')); put(21, pg.get('standfirst'))
            for k, col in enumerate(pg.get('columns', [])):
                put(30 + k, col)
            if lay == 'R08' and pg.get('table'):
                rows = pg['table']; nc = max(len(r) for r in rows)
                p = ph(s, 30)
                gf = p.insert_table(len(rows), nc); used.add(30); t = gf.table
                tp = t._tbl.tblPr; tp.set('bandRow', '0')
                sid = tp.find(A + 'tableStyleId')
                if sid is not None:
                    sid.text = '{2D5ABB26-0587-4C30-8999-92F81FD0307C}'
                widths = [max(len(r[c]) if c < len(r) else 0 for r in rows) for c in range(nc)]
                tw = sum(min(w, 60) + 12 for w in widths)
                for c in range(nc):
                    t.columns[c].width = Emu(int(11049000 * (min(widths[c], 60) + 12) / tw))
                for r, row in enumerate(rows):
                    for c in range(nc):
                        cell = t.cell(r, c); cell.text = row[c] if c < len(row) else ''
                        cell.margin_left = cell.margin_right = Emu(120000)
                        cell.margin_top = cell.margin_bottom = Emu(70000)
                        cell.vertical_anchor = MSO_ANCHOR.MIDDLE
                        for para in cell.text_frame.paragraphs:
                            for run in para.runs:
                                run.font.size = Pt(10.5)
                                run.font.color.rgb = WHITE if r == 0 else NAVY
                                if r == 0 or c == 0:
                                    run.font.name = 'Effra Medium'
                        cell.fill.solid(); cell.fill.fore_color.rgb = NAVY if r == 0 else WHITE
                        tcPr = cell._tc.get_or_add_tcPr()
                        ln = etree.Element(A + 'lnB', w='9525')
                        sf = etree.SubElement(ln, A + 'solidFill'); etree.SubElement(sf, A + 'srgbClr', val='C2D0DA')
                        tcPr.insert(0, ln)
                put(31, pg.get('notes'))
            if lay == 'R06':
                put(40, pg.get('side_label')); put(41, pg.get('side_figure'))
                put(42, pg.get('side_caption')); put(43, pg.get('side_items'))
            if lay == 'R07':
                p = ph(s, 31)
                if p is not None and pg.get('image') and os.path.exists(pg['image']):
                    p.insert_picture(pg['image']); used.add(31)
                put(32, pg.get('caption'))
            if lay == 'R10':
                for k, pt in enumerate(pg.get('points', [])[:3]):
                    put(40 + 3 * k, f'0{k+1}'); put(41 + 3 * k, pt['heading']); put(42 + 3 * k, pt['text'])
        # remove empty placeholders so nothing prints as a prompt
        for p in list(s.placeholders):
            idx = p.placeholder_format.idx
            if p.placeholder_format.type is not None and 'TITLE' in str(p.placeholder_format.type):
                continue
            if idx not in used:
                p._element.getparent().remove(p._element)
        # tags
        tb = s.shapes.add_textbox(0, 0, Emu(10), Emu(10)); tb.name = 'TAGS'
        n = 0
        for col in pg.get('columns', []):
            n += words(col)
        tb.text_frame.text = f"CO_MODE: read | CO_LAYOUT: {lay} | CO_WORDS: {n}"
        tb._element.nvSpPr.cNvPr.set('hidden', '1')
    # keep only the new pages
    lst = prs.slides._sldIdLst
    for e in orig:
        prs.part.drop_rel(e.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'))
        lst.remove(e)
    P14 = 'http://schemas.microsoft.com/office/powerpoint/2010/main'
    secl = prs.part._element.find('.//{%s}sectionLst' % P14)
    if secl is not None:
        for sec in list(secl):
            secl.remove(sec)
        sec = etree.SubElement(secl, '{%s}section' % P14, name='Reading document',
                               id='{5C2E7B1A-3D4F-4A6B-9C8D-0E1F2A3B4C5D}')
        sl = etree.SubElement(sec, '{%s}sldIdLst' % P14)
        for e in lst:
            etree.SubElement(sl, '{%s}sldId' % P14, id=e.get('id'))
    prs.save(out)
    return len(made)


if __name__ == '__main__':
    cmd = sys.argv[1]
    if cmd == 'plan':
        doc = read_docx(sys.argv[2])
        args = sys.argv[4:]
        dt = args[args.index('--doc-type') + 1] if '--doc-type' in args else 'Document'
        sh = args[args.index('--short') + 1] if '--short' in args else None
        pl = plan(doc, dt, sh)
        json.dump(pl, open(sys.argv[3], 'w'), indent=1, ensure_ascii=False)
        print(f"{len(pl)} pages planned:")
        for i, p in enumerate(pl, 1):
            extra = ''
            if 'columns' in p:
                extra = ' | words per column: ' + ', '.join(str(words(c)) for c in p['columns'])
            print(f"  {i:2d}. {p['layout']}  {p.get('title','')}{extra}")
    elif cmd == 'build':
        args = sys.argv[4:]
        tpl = args[args.index('--template') + 1] if '--template' in args else None
        img = args[args.index('--cover-image') + 1] if '--cover-image' in args else None
        n = build(json.load(open(sys.argv[2])), sys.argv[3], tpl, img)
        print(f"built {n} pages -> {sys.argv[3]}")
