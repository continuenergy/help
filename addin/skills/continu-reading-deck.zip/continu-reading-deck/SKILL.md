---
name: continu-reading-deck
description: Turn a Word document (or long pasted text) into a Continu reading deck – dense, text-led pages built only from the "Continu Read" slide master. Use when someone attaches a .docx or asks for a report, document-style deck, docuslide, leave-behind or "text-heavy" version. Always asks first whether they want a presentation or a reading document.
---

# Continu reading deck (Word → Read pages)

Builds **reading** pages – documents people read, not slides people present – from the
**Continu Read** master in the Continu template. The presentation layouts in the main
master are never used by this skill.

## Step 1 – ask the mode question first

Before anything else, ask (as a clickable question if the tool supports it):

> **What kind of output do you want from this document?**
> - **Reading document** – full detail, dense text pages to send or leave behind (this skill)
> - **Presentation** – key points only, for presenting (hand over to the Continu presentation skills)

If they choose Presentation, stop and use the presentation skill instead.

Then ask only what you can't find in the document:
- Short name for the page labels (e.g. "Customer success playbook")
- Document type for the cover (e.g. INTERNAL GUIDE, PROPOSAL, TECHNICAL DOCUMENT)
- Who it's prepared for, if anyone

## Step 2 – plan the pages

Read the Word document in order. Heading 1 = a new page (section). Heading 2 = a subhead
inside the page. Lists stay as bullets. Tables stay as tables.

Choose a layout for each section (full placeholder positions in `references/layouts.md`):

| Content | Layout | Word budget |
|---|---|---|
| Document start | R01 Cover | title ≤ 8 words |
| 4+ sections | R02 Contents | one line per section |
| Long document, new part | R03 Section opener (navy) | intro ≤ 40 words |
| Normal section | R04 Two-column text | ≈ 300 words |
| Longer section, or exactly 3 subheads | R05 Three-column text | ≈ 330 words |
| Section with one key number or fact list | R06 Text with sidebar | ≈ 240 words + sidebar |
| Short section (< 100 words) with a good photo | R07 Text with image | ≈ 150 words |
| Section built around a table | R08 Text with table | ≤ 8 rows × 5 cols |
| Section built around figures that compare | R09 Text with chart | ≤ 80 words |
| Conclusions / summary with 3 points | R10 Key takeaways | 3 × ≤ 40 words |
| Assumptions, specifications, calculations | R11 Appendix (9pt) | ≈ 600 words |

Rules:
1. **Never shrink text and never use autofit.** If a section is longer than the budget,
   continue it on a second page with the same layout and "(continued)" in the title.
   Share the text evenly across the pages; break pages between subheads, not in the
   middle of one.
2. **Split columns at subheads** and balance them, so columns end at roughly the same height.
   Never leave a subhead at the bottom of a column on its own.
3. **Merge short neighbours.** Two or three consecutive sections under ~100 words each go on
   one page, one section per column, with a combined title (e.g. "Tools, training and review").
4. **Write a standfirst for every page** (the one-line intro under the title): ≤ 30 words,
   taken from the section's own content. Never add facts, figures or claims that aren't in
   the document.
5. **Keep the author's words.** Fix obvious typos and Americanisms (British English), but
   don't rewrite or summarise body text unless asked – this is a reading document.
6. Page label (top-left, sentence case, no letter-spacing): `NN  Section name  |  Short name`.
7. Remove any placeholder that isn't used, so no prompt text is left on the page.
8. Tag every page: a hidden text box named `TAGS` containing
   `CO_MODE: read | CO_LAYOUT: R04 | CO_WORDS: 280`.

Show the person the plan as a short list (page – layout – title) before building, and adjust
if they ask.

## Step 3 – build

### Route A: you can run code (Claude with code execution, ChatGPT with code)

```bash
python3 scripts/read_deck.py plan  input.docx plan.json --doc-type "INTERNAL GUIDE" --short "Customer success playbook"
# review plan.json: write standfirsts, merge or retitle pages, pick R06/R07/R09/R10 where they fit
python3 scripts/read_deck.py build plan.json output.pptx [--template assets/Continu_Template.pptx] [--cover-image photo.jpg]
```

The planner applies rules 1–3 automatically (line-based fitting, even page sharing, merging).
Your job is the review: standfirsts, better titles, and choosing richer layouts (image,
sidebar, chart, takeaways) where the content suits them. Then render the output to PDF and
look at every page before handing it over: no text past the footer rule, no empty columns,
no lone subheads.

### Route B: inside PowerPoint (Claude for PowerPoint / ChatGPT for PowerPoint)

The open file must be the Continu template (it contains the Continu Read master).

```js
await PowerPoint.run(async (context) => {
  const masters = context.presentation.slideMasters;
  masters.load("items/id,items/name,items/layouts/items/id,items/layouts/items/name");
  await context.sync();
  const read = masters.items.find(m => m.name === "Continu Read");
  const layout = read.layouts.items.find(l => l.name === "Read | 04 Two-column text");
  context.presentation.slides.add({ slideMasterId: read.id, layoutId: layout.id });
  await context.sync();
  // then load the new slide's shapes (name,left,top,width,height) and fill each placeholder,
  // matching it by position from references/layouts.md
});
```

- Subheads: set the run's font name to **Effra Medium**. Bullets: set
  `paragraphFormat.indentLevel = 1` (PowerPointApi 1.10) on bullet paragraphs.
- Tables: `shapes.addTable(rows, columns, { values, left, top, width })` at the R08 table position;
  header row navy (#324E64) with white Effra Medium text, body rows white with a thin #C2D0DA
  rule under each row.
- Charts can't be created from the add-in: use a table, or ask the person to paste a chart.
- New pages go in a section called "Reading document" at the front.

## Step 4 – finish

Tell the person how many pages were made, which sections were merged or continued, and
anything you left out (e.g. a chart you couldn't create). Offer the presentation version
as a next step if they might present it.

## For the presentation skills

Presentation skills must ignore the **Continu Read** master and any slide tagged
`CO_MODE: read`, unless the person asks to include reading pages (for example as an appendix).
