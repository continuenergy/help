---
name: continu-sales-proposal
description: "Build the Continu sales proposal (Operational Energy User, 32 slides) from the tagged Continu template open in PowerPoint. FIRST ACTION, before reading anything: unless the user already gave all three answers, call request_user_input_basispoints once with three questions – 'Company name?' (options 'Test Company', 'Leave the placeholder'; they can type a name in Other), 'Who is presenting?' (options 'Alison McFadden', 'Gavin', 'Someone else'), 'Has there been a discovery call?' (options 'Yes – include the recap', 'No – skip the recap'). Then build without further questions."
---

# Continu sales proposal (ChatGPT)

Answers come from the clickable question (or the user's message). "Someone else" as presenter: use the CO_DEFAULT close slide and flag the contact details at the end.

## How the template works
- Every library slide is tagged. Read the tags from the slide's built-in tags (CO_ID, CO_KIND, CO_RECIPE, CO_PRESENTER, CO_DEFAULT, CO_OPTIONAL, CO_FIT). If you can't read built-in tags, read the hidden text box named **TAGS** on each slide (line 1 = tags, line 2 = FIT).
- The sales proposal = every slide whose CO_RECIPE contains `energy-user:NN`, in NN order (32 positions).
- Two slides at one position are alternatives: pick the one whose CO_PRESENTER matches the presenter's first name, otherwise the one with CO_DEFAULT=yes.
- CO_OPTIONAL: skip the recap slide if there was no discovery call.
- Never use slides with CO_KIND=divider. Find slides by tags, never by slide number.

## Build (no questions during the build)
1. **Duplicate** (never move or edit) the chosen slides, in order, to the very top of the file, into the first section (named "New Deck"). Library slides stay untouched below.
2. Delete the hidden **TAGS** text box from each copy.
3. On the cover copy, set the small line at the bottom to: "Prepared for <Company> by <Presenter>, Continu". Don't change anything else.
4. Copy fit: if you change any text, keep it to the length in that slide's CO_FIT (same lines, characters within ~10%). Never change font size, box size or position. Never invent figures.
5. **Check:** count the new slides – 32, or 31 without the recap. If fewer, find the missing positions by CO_RECIPE and add them. Select slide 1.

## Finish (one message, no further questions in this reply)
"**Your deck for <Company> is ready – slides 1–<N>** (New Deck section). Everything below is the slide library.
Still to check by hand: <only what applies – chart data, contact details for a presenter other than Alison or Gavin, photos to swap>.
- Reply **delete library** to remove the library slides (only slides <N+1> onwards).
- Reply **PowerPoint help** for how-tos."
If the user later replies "delete library": delete only slides <N+1> to the end, never 1–<N>, then tell them: right-click a section name → Remove All Sections, and File → Save As with a new name.

## Running order (check against the tags – the tags win)
 1. Cover: deck title, company name, presenter – title starts “Taking back control of your energy”
 2. Agenda – title starts “What we'll cover” (optional: Skip for a short read-ahead deck)
 3. Recap of the discovery call / priorities – title starts “Recap of our call” (optional: Only when there was a discovery call)
 4. The three challenges we solve – title starts “The challenges we”
 5. Electrification, automation, digitalisation – title starts “Right now, every industry is shifting”
 6. Energy anxiety across roles – title starts “And rising energy dependence”
 7. Built-in cost disadvantage (UK vs US prices) – title starts “UK businesses”
 8. Price volatility: +77% – title starts “Volatility has become”
 9. Demand growing faster than the grid (41GW to 125GW) – title starts “Demand is growing”
10. Quote: grid struggling to keep up – title starts “Ireland is already oversaturated”
11. Power quality is getting worse (data) – title starts “power quality issues are set to”
12. Cost of downtime: £3,500/min – title starts “When the production flow stops”
13. Partial fixes create bigger problems – title starts “Partial fixes create”
14. Labour and materials are controlled, energy is not – title starts “Labour and materials are”
15. A solution that works: one connected system – title starts “Take control of your energy with one”
16. Why choose Continu – title starts “Why choose Continu?”
17. The team (front-end build) – title starts “A specialist team built to deliver”
18. Awards – title starts “Award-winning capability”
19. Sectors and partner ecosystem – title starts “Power-critical sectors trust Continu”
20. Track record and case studies – title starts “Our track record shows we can deliver”
21. The site-wide approach – title starts “We take a site-wide approach”
22. The Endless Energy Accelerator (5 steps) – title starts “How we do it: The Endless Energy Accelerator”
23. Step 1: Tailored, Optimised Design – title starts “Understand the whole”
24. Step 2: Trusted Install and Commission – title starts “Move from approved design”
25. Step 3: On the Gemba Training – title starts “Give site teams”
26. Step 4: Seamless Service Support – title starts “Our support is tailored”
27. Step 5: Continu.eye Remote Monitoring – title starts “See the issue”
28. Case study: challenge and solution (front-end build) – title starts “From complexity”
29. Case study: results (front-end build) – title starts “The Value Created”
30. Three client quotes – title starts “What our clients are saying”
31. Single client quote with photos – title starts “Continu provided a clean power”
32. Call to action: lunch and learn (Alison) – title starts “starts with Lean energy” – Alison McFadden version / Gavin: Call to action: lunch and learn (Gavin's details)

Say "company", never "prospect". Do not fetch anything from the web.
