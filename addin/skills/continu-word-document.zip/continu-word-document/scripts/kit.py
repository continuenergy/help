"""Continu Word kit (v2): typography, grid and page parts for A4 Word documents.

Grid: A4, 18 mm side margins, two text columns with an 8 mm gutter.
Type: Effra Light display and headings (two-tone with Effra Medium), Effra 9/13.5 body,
exact leading everywhere, tracking set per style, kerning on.
Everything sits inside the margins. Colour comes from navy/grey panels inside the
grid and from whole-page tints (navy for covers and dividers, light grey for
contents and summary pages).
"""
import os
from docx import Document
from docx.shared import Pt, Mm, Emu, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.enum.section import WD_SECTION
from docx.oxml.ns import qn, nsdecls, nsmap
nsmap.setdefault('wps', 'http://schemas.microsoft.com/office/word/2010/wordprocessingShape')
from docx.oxml import parse_xml, OxmlElement
from PIL import Image, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__))
ASSET = os.path.join(HERE, 'assets') if os.path.isdir(os.path.join(HERE, 'assets')) else os.path.join(HERE, '..', 'assets')

NAVY, NAVY2, GREY, LIME, RULE, WHITE, MUTED = '324E64', '2A4356', 'E6EAE4', 'B5EB03', 'C2D0DA', 'FFFFFF', '6B8191'
# Font names as Continu's own PowerPoint template uses them (EFFRA-LIGHT renders as Light on Mac and PC;
# 'Effra Light' falls back to the italic on Mac).
F_REG, F_LIGHT, F_MED = 'Effra', 'EFFRA-LIGHT', 'Effra Medium'
PAGE_W, PAGE_H = Mm(210), Mm(297)
ML = MR = Mm(18); MT = Mm(22); MB = Mm(20)
TEXT_W = PAGE_W - ML - MR                 # 174 mm
GUTTER = Mm(8)
COL_W = int((TEXT_W - GUTTER) / 2)        # 83 mm
TW = lambda emu: int(emu / 635)           # EMU -> twips

# ------------------------------------------------------------------ images
def donut(src, out, size=900, hole=0.42):
    im = Image.open(src).convert('RGB')
    s = min(im.size); l = (im.width - s) // 2; t = (im.height - s) // 2
    im = im.crop((l, t, l + s, t + s)).resize((size, size), Image.LANCZOS)
    big = size * 4
    m = Image.new('L', (big, big), 0); d = ImageDraw.Draw(m)
    d.ellipse((0, 0, big - 1, big - 1), fill=255)
    r = big * hole / 2; c = big / 2
    d.ellipse((c - r, c - r, c + r, c + r), fill=0)
    im.putalpha(m.resize((size, size), Image.LANCZOS)); im.save(out, optimize=True); return out


def rounded(src, out, w=1400, ratio=0.42, radius=0.03, bg=(255, 255, 255)):
    im = Image.open(src).convert('RGB')
    h = int(w * ratio)
    if im.width / im.height > w / h:
        nw = int(im.height * w / h); l = (im.width - nw) // 2; im = im.crop((l, 0, l + nw, im.height))
    else:
        nh = int(im.width * h / w); t = (im.height - nh) // 2; im = im.crop((0, t, im.width, t + nh))
    im = im.resize((w, h), Image.LANCZOS)
    big = Image.new('L', (w * 4, h * 4), 0)
    ImageDraw.Draw(big).rounded_rectangle((0, 0, w * 4 - 1, h * 4 - 1), radius=int(min(w, h) * 4 * radius * 2), fill=255)
    canvas = Image.new('RGB', (w, h), bg); canvas.paste(im, (0, 0), big.resize((w, h), Image.LANCZOS))
    out = os.path.splitext(out)[0] + '.jpg'; canvas.save(out, quality=85); return out

# ------------------------------------------------------------------ styles
def _font(rpr, font):
    rf = rpr.find(qn('w:rFonts'))
    if rf is None:
        rf = OxmlElement('w:rFonts'); rpr.insert(0, rf)
    for a in list(rf.attrib):
        del rf.attrib[a]
    for a in ('w:ascii', 'w:hAnsi', 'w:cs', 'w:eastAsia'):
        rf.set(qn(a), font)


def _set(rpr, tag, **attrs):
    e = rpr.find(qn(tag))
    if e is None:
        e = OxmlElement(tag); rpr.append(e)
    for k, v in attrs.items():
        e.set(qn(k), str(v))


def style_def(doc, name, font, size, lead, color=NAVY, before=0, after=0, track=0, caps=False,
              keep=False, base='Normal', indent=None):
    from docx.enum.style import WD_STYLE_TYPE
    try:
        s = doc.styles[name]
    except KeyError:
        s = doc.styles.add_style(name, WD_STYLE_TYPE.PARAGRAPH); s.base_style = doc.styles[base]
    s.quick_style = True
    f = s.font; f.size = Pt(size); f.color.rgb = RGBColor.from_string(color)
    f.bold = False; f.italic = False; f.all_caps = caps
    rpr = s.element.get_or_add_rPr(); _font(rpr, font)
    _set(rpr, 'w:kern', **{'w:val': 16})
    if track:
        _set(rpr, 'w:spacing', **{'w:val': int(track)})
    pf = s.paragraph_format
    pf.space_before = Pt(before); pf.space_after = Pt(after); pf.line_spacing = Pt(lead)
    pf.keep_with_next = keep; pf.widow_control = True
    ppr = s.element.get_or_add_pPr()
    for b in ppr.findall(qn('w:pBdr')):
        ppr.remove(b)
    return s


def setup(doc):
    sec = doc.sections[0]
    sec.page_width, sec.page_height = PAGE_W, PAGE_H
    sec.left_margin, sec.right_margin, sec.top_margin, sec.bottom_margin = ML, MR, MT, MB
    sec.header_distance, sec.footer_distance = Mm(9), Mm(9)
    # modern table layout: table edges line up with the text margin on PC and Mac
    st = doc.settings.element
    for c in st.findall(qn('w:compat')):
        st.remove(c)
    st.append(parse_xml(f'<w:compat {nsdecls("w")}><w:compatSetting w:name="compatibilityMode" '
                        f'w:uri="http://schemas.microsoft.com/office/word" w:val="15"/></w:compat>'))
    #           name            font     size lead  colour  before after track caps keep
    style_def(doc, 'Normal',      F_REG,   9,  13.5, NAVY,   0, 7)
    style_def(doc, 'Title',       F_LIGHT, 38, 41,   WHITE,  0, 14, -8)
    style_def(doc, 'Subtitle',    F_LIGHT, 14, 19,   WHITE,  0, 8)
    style_def(doc, 'Heading 1',   F_LIGHT, 26, 29,   NAVY,   0, 12, -6, keep=True)
    style_def(doc, 'Heading 2',   F_MED,   10, 13.5, NAVY,  10, 3, 2, keep=True)
    style_def(doc, 'Heading 3',   F_MED,   9,  13,   NAVY,   6, 2, 2, keep=True)
    style_def(doc, 'Label',       F_MED,   8,  11,   MUTED,  0, 6, 0, keep=True)
    style_def(doc, 'Standfirst',  F_LIGHT, 13, 18,   NAVY,   0, 16, -2)
    style_def(doc, 'Big Number',  F_LIGHT, 36, 38,   NAVY,   0, 4, -14)
    style_def(doc, 'Pull Quote',  F_LIGHT, 15, 20,   NAVY,   0, 10, -4)
    style_def(doc, 'Box Text',    F_REG,   8.5, 12.5, NAVY,  0, 5)
    style_def(doc, 'Box Heading', F_MED,   9.5, 13,  NAVY,   0, 3, 2)
    style_def(doc, 'White Text',  F_REG,   9,  13.5, WHITE,  0, 4)
    style_def(doc, 'Caption',     F_REG,   7,  10,   MUTED,  5, 12, 4)
    style_def(doc, 'List Bullet', F_REG,   9,  13.5, NAVY,   0, 4)
    style_def(doc, 'Header',      F_REG,   7,  10,   MUTED,  0, 0, 4)
    style_def(doc, 'Footer',      F_REG,   7,  10,   MUTED,  0, 0, 4)
    for nm in ('Header', 'Footer'):
        ppr = doc.styles[nm].element.get_or_add_pPr()
        for t in ppr.findall(qn('w:tabs')):
            ppr.remove(t)
    # bullets: hanging indent, small navy bullet
    lbp = doc.styles['List Bullet'].element.get_or_add_pPr()
    for n in lbp.findall(qn('w:numPr')):
        lbp.remove(n)
    lb = doc.styles['List Bullet'].paragraph_format
    lb.left_indent = Pt(11); lb.first_line_indent = Pt(-11)
    _table_style(doc)
    return doc


def _table_style(doc):
    xml = f'''<w:style {nsdecls("w")} w:type="table" w:customStyle="1" w:styleId="ContinuTable">
  <w:name w:val="Continu Table"/><w:basedOn w:val="TableNormal"/><w:uiPriority w:val="40"/><w:qFormat/>
  <w:pPr><w:spacing w:before="0" w:after="0" w:line="250" w:lineRule="exact"/></w:pPr>
  <w:rPr><w:rFonts w:ascii="{F_REG}" w:hAnsi="{F_REG}"/><w:color w:val="{NAVY}"/><w:sz w:val="16"/></w:rPr>
  <w:tblPr><w:tblBorders><w:bottom w:val="single" w:sz="4" w:color="{RULE}"/><w:insideH w:val="single" w:sz="4" w:color="{RULE}"/></w:tblBorders>
    <w:tblCellMar><w:top w:w="110" w:type="dxa"/><w:left w:w="140" w:type="dxa"/><w:bottom w:w="110" w:type="dxa"/><w:right w:w="140" w:type="dxa"/></w:tblCellMar></w:tblPr>
  <w:tblStylePr w:type="firstRow"><w:tcPr><w:shd w:val="clear" w:color="auto" w:fill="{NAVY}"/></w:tcPr></w:tblStylePr>
  <w:tblStylePr w:type="lastRow"><w:tcPr><w:shd w:val="clear" w:color="auto" w:fill="{GREY}"/></w:tcPr></w:tblStylePr>
</w:style>'''
    doc.styles.element.append(parse_xml(xml))

# ------------------------------------------------------------------ text helpers
_id = [100]
def _nid():
    _id[0] += 1; return _id[0]


def run(p, text, font=None, color=None, size=None, track=None):
    r = p.add_run(text)
    if font:
        _font(r._element.get_or_add_rPr(), font)
    if color: r.font.color.rgb = RGBColor.from_string(color)
    if size: r.font.size = Pt(size)
    if track is not None:
        _set(r._element.get_or_add_rPr(), 'w:spacing', **{'w:val': int(track)})
    return r


def para(c, text='', style=None, after=None, before=None, align=None, color=None, font=None, size=None):
    if hasattr(c, 'paragraphs') and hasattr(c, '_tc') and len(c.paragraphs) == 1 and not c.paragraphs[0].runs \
            and not getattr(c, '_used', False):
        p = c.paragraphs[0]; c._used = True
        if style: p.style = style
    else:
        p = c.add_paragraph(style=style)
    if text:
        run(p, text, font, color, size)
    if after is not None: p.paragraph_format.space_after = Pt(after)
    if before is not None: p.paragraph_format.space_before = Pt(before)
    if align == 'right': p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    return p


def two_tone(c, strong, light='', style='Heading 1', color=NAVY, after=None):
    """Heading with a Medium phrase followed by a Light phrase (as in the reference)."""
    p = para(c, style=style, after=after)
    run(p, strong, F_MED, color)
    if light:
        run(p, ' ' + light, F_LIGHT, color)
    return p


def bullet(c, text, lead=''):
    p = para(c, style='List Bullet')
    run(p, '•\t', F_MED)
    p.paragraph_format.tab_stops.add_tab_stop(Pt(11))
    if lead:
        run(p, lead + '  ', F_MED)
    run(p, text)
    return p


def write_items(c, items):
    for it in items:
        k = it[0]
        if k == 'h': para(c, it[1], 'Heading 2')
        elif k == 'p': para(c, it[1])
        elif k == 'b': bullet(c, it[1], it[2] if len(it) > 2 else '')


def vgap(c, mm):
    p = c.add_paragraph(); pf = p.paragraph_format
    pf.space_before = Mm(mm); pf.space_after = Pt(0); pf.line_spacing = Pt(1)
    run(p, '', size=1)
    return p

# ------------------------------------------------------------------ tables as layout
_TC_ORDER = ['cnfStyle', 'tcW', 'gridSpan', 'hMerge', 'vMerge', 'tcBorders', 'shd', 'noWrap', 'tcMar',
             'textDirection', 'tcFitText', 'vAlign', 'hideMark']
def _order(cell):
    tcPr = cell._tc.get_or_add_tcPr()
    kids = list(tcPr)
    kids.sort(key=lambda e: _TC_ORDER.index(e.tag.split('}')[1]) if e.tag.split('}')[1] in _TC_ORDER else 99)
    for k in kids:
        tcPr.remove(k); tcPr.append(k)


def shade(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    for o in tcPr.findall(qn('w:shd')): tcPr.remove(o)
    tcPr.append(parse_xml(f'<w:shd {nsdecls("w")} w:val="clear" w:color="auto" w:fill="{fill}"/>'))
    _order(cell)


def pad(cell, top=0, left=0, bottom=0, right=0):
    tcPr = cell._tc.get_or_add_tcPr()
    tcPr.append(parse_xml(f'<w:tcMar {nsdecls("w")}><w:top w:w="{top}" w:type="dxa"/><w:left w:w="{left}" w:type="dxa"/>'
                          f'<w:bottom w:w="{bottom}" w:type="dxa"/><w:right w:w="{right}" w:type="dxa"/></w:tcMar>'))
    _order(cell)


def border(cell, side, sz=8, color=NAVY):
    tcPr = cell._tc.get_or_add_tcPr()
    b = tcPr.find(qn('w:tcBorders'))
    if b is None:
        b = OxmlElement('w:tcBorders'); tcPr.append(b)
    b.append(parse_xml(f'<w:{side} {nsdecls("w")} w:val="single" w:sz="{sz}" w:space="0" w:color="{color}"/>'))
    _order(cell)


def grid(c, widths, rows=1, indent=0):
    """Borderless layout table with fixed column widths (tblGrid set, which Word uses)."""
    t = c.add_table(rows=rows, cols=len(widths)); t.autofit = False
    pr = t._tbl.tblPr
    pr.append(parse_xml(f'<w:tblW {nsdecls("w")} w:w="{TW(sum(widths))}" w:type="dxa"/>'))
    pr.append(parse_xml(f'<w:tblInd {nsdecls("w")} w:w="{TW(indent)}" w:type="dxa"/>'))
    pr.append(parse_xml(f'<w:tblLayout {nsdecls("w")} w:type="fixed"/>'))
    pr.append(parse_xml(f'<w:tblBorders {nsdecls("w")}><w:top w:val="nil"/><w:left w:val="nil"/><w:bottom w:val="nil"/>'
                        f'<w:right w:val="nil"/><w:insideH w:val="nil"/><w:insideV w:val="nil"/></w:tblBorders>'))
    pr.append(parse_xml(f'<w:tblCellMar {nsdecls("w")}><w:top w:w="0" w:type="dxa"/><w:left w:w="0" w:type="dxa"/>'
                        f'<w:bottom w:w="0" w:type="dxa"/><w:right w:w="0" w:type="dxa"/></w:tblCellMar>'))
    g = t._tbl.find(qn('w:tblGrid'))
    for gc, w in zip(g.findall(qn('w:gridCol')), widths):
        gc.set(qn('w:w'), str(TW(w)))
    for r in t.rows:
        for cell, w in zip(r.cells, widths):
            cell.width = w
    return t


def band(doc, fill=GREY, top=420, bottom=380):
    """CO_W_BAND – colour from page edge to page edge. Text inside lines up with the margins.
    Use only in full-width (one-column) parts of the page."""
    t = grid(doc, [PAGE_W], indent=-ML)
    cell = t.rows[0].cells[0]; shade(cell, fill); pad(cell, top, TW(ML), bottom, TW(MR))
    return cell


def panel(c, width=None, fill=GREY, padding=(300, 320, 260, 320)):
    """A coloured box inside the grid. Returns the cell to write into."""
    t = grid(c, [width or TEXT_W])
    cell = t.rows[0].cells[0]; shade(cell, fill); pad(cell, *padding)
    return cell

# ------------------------------------------------------------------ sections, header, footer
def _clear(hf):
    for p in hf.paragraphs:
        for r in list(p.runs):
            r._element.getparent().remove(r._element)


def set_cols(section, n):
    sp = section._sectPr
    for c in sp.findall(qn('w:cols')): sp.remove(c)
    el = parse_xml(f'<w:cols {nsdecls("w")} w:num="{n}" w:space="{TW(GUTTER)}" w:equalWidth="1"/>')
    pg = sp.find(qn('w:docGrid'))
    if pg is not None: pg.addprevious(el)
    else: sp.append(el)


def columns(doc, n):
    """Start a continuous section with n columns. Call columns(doc, 1) to return to full width."""
    s = doc.add_section(WD_SECTION.CONTINUOUS); set_cols(s, n); return s


def new_page_section(doc, cols=1):
    s = doc.add_section(WD_SECTION.NEW_PAGE)
    s.page_width, s.page_height = PAGE_W, PAGE_H
    s.left_margin, s.right_margin, s.top_margin, s.bottom_margin = ML, MR, MT, MB
    set_cols(s, cols)
    return s


def interior_header_footer(doc, section, running):
    section.header.is_linked_to_previous = False
    section.footer.is_linked_to_previous = False
    h = section.header; _clear(h)
    hp = h.paragraphs[0]; hp.style = doc.styles['Header']
    hp.paragraph_format.tab_stops.add_tab_stop(Emu(TEXT_W), 2); hp.paragraph_format.line_spacing = 1.0
    run(hp, running)
    run(hp, '\t').add_picture(os.path.join(ASSET, 'logo_navy.png'), height=Mm(5))
    f = section.footer; _clear(f)
    fp = f.paragraphs[0]; fp.style = doc.styles['Footer']
    fp.paragraph_format.tab_stops.add_tab_stop(Emu(TEXT_W), 2)
    run(fp, '© Continu 2026   continuenergy.com\t')
    r = run(fp, '', F_MED)
    for kind, txt in (('begin', None), (None, ' PAGE '), ('end', None)):
        if kind:
            e = OxmlElement('w:fldChar'); e.set(qn('w:fldCharType'), kind); r._r.append(e)
        else:
            it = OxmlElement('w:instrText'); it.set(qn('xml:space'), 'preserve'); it.text = txt; r._r.append(it)


def blank_header_footer(section):
    section.header.is_linked_to_previous = False
    section.footer.is_linked_to_previous = False
    _clear(section.header); _clear(section.footer)

# ------------------------------------------------------------------ floating graphics
def _anchor(p, graphic, x, y, w, h, behind, name):
    i = _nid()
    xml = (f'<wp:anchor {nsdecls("wp","a","pic","r")} distT="0" distB="0" distL="0" distR="0" simplePos="0" relativeHeight="{i}" '
           f'behindDoc="{1 if behind else 0}" locked="1" layoutInCell="1" allowOverlap="1">'
           f'<wp:simplePos x="0" y="0"/><wp:positionH relativeFrom="page"><wp:posOffset>{int(x)}</wp:posOffset></wp:positionH>'
           f'<wp:positionV relativeFrom="page"><wp:posOffset>{int(y)}</wp:posOffset></wp:positionV>'
           f'<wp:extent cx="{int(w)}" cy="{int(h)}"/><wp:effectExtent l="0" t="0" r="0" b="0"/><wp:wrapNone/>'
           f'<wp:docPr id="{i}" name="{name}"/><wp:cNvGraphicFramePr/>{graphic}</wp:anchor>')
    r = p.add_run(); d = OxmlElement('w:drawing'); d.append(parse_xml(xml)); r._r.append(d)


def page_tint(p, fill):
    g = (f'<a:graphic {nsdecls("a")}><a:graphicData uri="http://schemas.microsoft.com/office/word/2010/wordprocessingShape">'
         f'<wps:wsp {nsdecls("wps","a")}><wps:cNvSpPr/><wps:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="{int(PAGE_W)}" cy="{int(PAGE_H)}"/></a:xfrm>'
         f'<a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:solidFill><a:srgbClr val="{fill}"/></a:solidFill><a:ln><a:noFill/></a:ln></wps:spPr>'
         f'<wps:bodyPr/></wps:wsp></a:graphicData></a:graphic>')
    _anchor(p, g, 0, 0, PAGE_W, PAGE_H, True, 'Page colour')


def float_image(doc, p, path, x, y, w, h=None, name='Image'):
    if h is None:
        im = Image.open(path); h = int(w * im.height / im.width)
    rId, _ = doc.part.get_or_add_image(path)
    i = _nid()
    g = (f'<a:graphic {nsdecls("a")}><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">'
         f'<pic:pic {nsdecls("pic","a","r")}><pic:nvPicPr><pic:cNvPr id="{i}" name="{name}"/><pic:cNvPicPr/></pic:nvPicPr>'
         f'<pic:blipFill><a:blip r:embed="{rId}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>'
         f'<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="{int(w)}" cy="{int(h)}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr>'
         f'</pic:pic></a:graphicData></a:graphic>')
    _anchor(p, g, x, y, w, h, False, name)

# ------------------------------------------------------------------ page parts
def _navy_page(doc, image, tmp, tag, ring_y):
    p = para(doc, after=0); page_tint(p, NAVY)
    ring = donut(image, os.path.join(tmp, f'ring_{tag}.png'))
    float_image(doc, p, ring, Mm(104), ring_y, Mm(92), Mm(92), 'Brand ring')
    float_image(doc, p, os.path.join(ASSET, 'endless_energy_device.png'), Mm(160), ring_y - Mm(9), Mm(35), Mm(35), 'Endless Energy')
    float_image(doc, p, os.path.join(ASSET, 'logo_white.png'), ML, Mm(16), Mm(28), name='Logo')


def cover(doc, title_strong, title_light, subtitle, doc_type, prepared, image, tmp):
    """CO_W_COVER"""
    _navy_page(doc, image, tmp, 'cover', Mm(40))
    vgap(doc, 128)
    para(doc, doc_type, 'Label', color=LIME)
    p = para(doc, style='Title'); run(p, title_strong, F_MED)
    if title_light: run(p, ' ' + title_light, F_LIGHT)
    para(doc, subtitle, 'Subtitle')
    vgap(doc, 26)
    para(doc, prepared, 'White Text', after=0)


def divider(doc, number, title, intro, image, tmp):
    """CO_W_DIVIDER"""
    _navy_page(doc, image, tmp, 'div' + number, Mm(160))
    vgap(doc, 26)
    para(doc, number, 'Big Number', color=LIME, size=64, after=10)
    para(doc, title, 'Title')
    para(doc, intro, 'Subtitle')


def back_cover(doc, heading, lines, image, tmp):
    """CO_W_BACK_COVER"""
    _navy_page(doc, image, tmp, 'back', Mm(40))
    vgap(doc, 128)
    para(doc, 'Get in touch', 'Label', color=LIME)
    para(doc, heading, 'Title', size=30)
    vgap(doc, 4)
    for l in lines:
        para(doc, l, 'White Text', after=1)


def contents_page(doc, entries, tmp=None):
    """CO_W_CONTENTS – light grey page, numbered list in two columns."""
    p = para(doc, after=0); page_tint(p, GREY)
    para(doc, 'Contents', 'Label')
    two_tone(doc, 'What’s', 'inside', after=26)
    half = (len(entries) + 1) // 2
    t = grid(doc, [COL_W, GUTTER, COL_W])
    for side, chunk, start in ((0, entries[:half], 0), (2, entries[half:], half)):
        cell = t.rows[0].cells[side]
        it = grid(cell, [Mm(16), COL_W - Mm(16)], rows=len(chunk))
        for k, (e, row) in enumerate(zip(chunk, it.rows)):
            a, b = row.cells
            for cc in (a, b):
                border(cc, 'top', 4, RULE); pad(cc, 150, 0, 150, 0)
            para(a, f'{start+k+1:02d}', 'Big Number', size=16, after=0).paragraph_format.line_spacing = Pt(20)
            para(b, e, 'Box Heading', after=0, before=4)


def page_opener(doc, label, strong, light='', standfirst='', image=None, tmp=None, name='hero', fill=None):
    """Top of an interior page: optional photo, then label, two-tone heading and standfirst –
    on white, or on an edge-to-edge band (fill=GREY or NAVY)."""
    if image:
        img = rounded(image, os.path.join(tmp, name))
        p = doc.add_paragraph(); p.add_run().add_picture(img, width=TEXT_W)
        p.paragraph_format.space_after = Pt(10); p.paragraph_format.line_spacing = 1.0
    host = band(doc, fill, 440, 420) if fill else doc
    dark = fill == NAVY
    if label: para(host, label, 'Label', color=LIME if dark else None)
    h = two_tone(host, strong, light, color=WHITE if dark else NAVY)
    if standfirst:
        t = grid(host, [int(TEXT_W * 0.8)])
        para(t.rows[0].cells[0], standfirst, 'Standfirst', color=WHITE if dark else None, after=0 if fill else None)
    vgap(doc, 4 if fill else 1)


def body_columns(doc, items, n=2, inserts=None):
    """Flowing text in n columns. inserts: {index: callable(doc)} – parts placed in the flow
    (e.g. a pull-out box) before item[index]."""
    columns(doc, n)
    inserts = inserts or {}
    for i, it in enumerate(items):
        if i in inserts:
            inserts[i](doc)
        write_items(doc, [it])
    if len(items) in inserts:
        inserts[len(items)](doc)
    columns(doc, 1)


def pullout(doc, label, text, dark=True, width=None):
    """CO_W_PULLOUT – sits in a column (default) or across the page."""
    cell = panel(doc, width or COL_W, NAVY if dark else GREY, (260, 280, 220, 280))
    para(cell, label, 'Label', color=LIME if dark else MUTED)
    para(cell, text, 'Pull Quote', color=WHITE if dark else NAVY, size=13, after=0).paragraph_format.line_spacing = Pt(17.5)
    vgap(doc, 3)


def quote_panel(doc, text, who, fill=GREY):
    """CO_W_QUOTE – edge-to-edge grey band with a large quote."""
    cell = band(doc, fill, 520, 480)
    t = grid(cell, [int(TEXT_W * 0.82)])
    c = t.rows[0].cells[0]
    para(c, '“', 'Big Number', font=F_MED, size=44, after=0).paragraph_format.line_spacing = Pt(30)
    para(c, text, 'Pull Quote', size=20).paragraph_format.line_spacing = Pt(26)
    para(c, who, 'Label', after=0)
    vgap(doc, 6)


def takeaways(doc, points, title='Key takeaways', fill=GREY):
    """CO_W_TAKEAWAYS – edge-to-edge grey band, three numbered white cards."""
    cell = band(doc, fill, 440, 460)
    para(cell, title, 'Label')
    gap = Mm(4); w = int((TEXT_W - 2 * gap) / 3)
    t = grid(cell, [w, gap, w, gap, w])
    for k, (h, tx) in enumerate(points[:3]):
        c = t.rows[0].cells[2 * k]; shade(c, WHITE); pad(c, 260, 260, 280, 260)
        para(c, f'{k+1:02d}', 'Big Number', size=26, after=8)
        para(c, h, 'Box Heading')
        para(c, tx, 'Box Text', after=0)
    vgap(doc, 6)


def stats(doc, items):
    """CO_W_STATS – two to four big numbers, navy rule above each."""
    n = len(items); gap = Mm(6); w = int((TEXT_W - (n - 1) * gap) / n)
    ws = []
    for i in range(n):
        ws += [w] + ([gap] if i < n - 1 else [])
    t = grid(doc, ws)
    for k, (num, lab) in enumerate(items):
        c = t.rows[0].cells[2 * k]; border(c, 'top', 12, NAVY); pad(c, 160, 0, 0, 0)
        para(c, num, 'Big Number')
        para(c, lab, 'Box Text', after=0)
    vgap(doc, 6)


def sidebar(doc, items, label, figure_txt, caption, facts):
    """CO_W_SIDEBAR – text in the wide column, grey 'at a glance' box in the narrow one."""
    sw = Mm(56); g = Mm(8)
    t = grid(doc, [TEXT_W - sw - g, g, sw])
    a, _, b = t.rows[0].cells
    write_items(a, items)
    shade(b, GREY); pad(b, 280, 260, 260, 260)
    para(b, label, 'Label')
    para(b, figure_txt, 'Big Number', size=30)
    para(b, caption, 'Box Text', after=10)
    for f in facts:
        bullet(b, f).style = doc.styles['Box Text']
    vgap(doc, 6)


def data_table(doc, rows, total_row=False, widths=None):
    """CO_W_TABLE"""
    t = doc.add_table(rows=len(rows), cols=len(rows[0]))
    t.style = doc.styles['Continu Table']
    pr = t._tbl.tblPr
    pr.append(parse_xml(f'<w:tblW {nsdecls("w")} w:w="{TW(TEXT_W)}" w:type="dxa"/>'))
    pr.append(parse_xml(f'<w:tblLook {nsdecls("w")} w:firstRow="1" w:lastRow="{1 if total_row else 0}" w:firstColumn="0" w:lastColumn="0" w:noHBand="1" w:noVBand="1" w:val="04A0"/>'))
    if not widths:
        lens = [max(len(r[c]) for r in rows) for c in range(len(rows[0]))]
        tot = sum(min(l, 70) + 10 for l in lens)
        widths = [int(TEXT_W * (min(l, 70) + 10) / tot) for l in lens]
    g = t._tbl.find(qn('w:tblGrid'))
    for gc, w in zip(g.findall(qn('w:gridCol')), widths):
        gc.set(qn('w:w'), str(TW(w)))
    for r, row in enumerate(rows):
        for c, v in enumerate(row):
            cell = t.cell(r, c); cell.width = widths[c]
            p = cell.paragraphs[0]; p.paragraph_format.space_after = Pt(0)
            hdr = r == 0; tot_r = total_row and r == len(rows) - 1
            run(p, v, F_MED if (hdr or c == 0 or tot_r) else F_REG, WHITE if hdr else NAVY, 8 if hdr else 8.5)
            if r < len(rows) - 1:
                p.paragraph_format.keep_with_next = True
        trPr = t.rows[r]._tr.get_or_add_trPr()
        trPr.append(parse_xml(f'<w:cantSplit {nsdecls("w")}/>'))
        if r == 0:
            trPr.append(parse_xml(f'<w:tblHeader {nsdecls("w")}/>'))
        for c, v in enumerate(row):
            cell = t.cell(r, c); p = cell.paragraphs[0]
            if hdr: shade(cell, NAVY)
            if tot_r: shade(cell, GREY)
            if c > 0 and any(ch.isdigit() for ch in v) and len(v) < 14:
                p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    vgap(doc, 6)
    return t


def figure(doc, image, caption, tmp, name='fig', ratio=0.42):
    """CO_W_IMAGE"""
    img = rounded(image, os.path.join(tmp, name), ratio=ratio)
    p = doc.add_paragraph(); p.add_run().add_picture(img, width=TEXT_W); p.paragraph_format.line_spacing = 1.0
    if caption: para(doc, caption, 'Caption')


def process(doc, steps, title=None):
    """CO_W_PROCESS – numbered cards, two per row, on light grey."""
    if title: para(doc, title, 'Label')
    rows = (len(steps) + 1) // 2; g = Mm(4); w = int((TEXT_W - g) / 2)
    t = grid(doc, [w, g, w], rows=rows * 2 - 1)
    for k, (h, tx) in enumerate(steps):
        r = (k // 2) * 2; c = t.rows[r].cells[(k % 2) * 2]
        shade(c, GREY); pad(c, 220, 240, 220, 240)
        tt = grid(c, [Mm(13), w - Emu(480 * 635) - Mm(13)])
        a, b = tt.rows[0].cells
        para(a, f'{k+1:02d}', 'Big Number', size=18, after=0)
        para(b, h, 'Box Heading', before=3)
        para(b, tx, 'Box Text', after=0)
    for r in range(1, rows * 2 - 1, 2):
        tr = t.rows[r]._tr
        trPr = tr.get_or_add_trPr(); trPr.append(parse_xml(f'<w:trHeight {nsdecls("w")} w:val="{TW(g)}" w:hRule="exact"/>'))
    vgap(doc, 6)


def case_study(doc, client, strong, light, challenge, solution, results, image, tmp):
    """CO_W_CASE_STUDY"""
    para(doc, 'Case study  |  ' + client, 'Label')
    two_tone(doc, strong, light)
    figure(doc, image, '', tmp, 'case', 0.38)
    vgap(doc, 2)
    t = grid(doc, [COL_W, GUTTER, COL_W])
    for cell, lab, txt in ((t.rows[0].cells[0], 'The challenge', challenge), (t.rows[0].cells[2], 'Our solution', solution)):
        para(cell, lab, 'Label'); para(cell, txt)
    vgap(doc, 4)
    if results: stats(doc, results)

# ------------------------------------------------------------------ library tags
def mark(doc):
    p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(0); p.paragraph_format.line_spacing = Pt(1)
    return p._p


def wrap_cc(doc, start_el, tag, alias):
    body = doc.element.body; kids = list(body); i = kids.index(start_el)
    els = []
    for e in kids[i:]:
        if e.tag == qn('w:sectPr'):
            break
        if e.tag == qn('w:p') and e.find('.//' + qn('w:sectPr')) is not None:
            break
        els.append(e)
    sdt = parse_xml(f'<w:sdt {nsdecls("w")}><w:sdtPr><w:alias w:val="{alias}"/><w:tag w:val="{tag}"/>'
                    f'<w:id w:val="{_nid()}"/></w:sdtPr><w:sdtContent/></w:sdt>')
    els[0].addprevious(sdt)
    for e in els:
        sdt.find(qn('w:sdtContent')).append(e)
