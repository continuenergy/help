#!/usr/bin/env python3
"""Continu Word document: any Word document -> branded Continu document built from the kit.

  python3 word_doc.py plan  input.docx plan.json [--doc-type "INTERNAL GUIDE"] [--short "Short name"]
  python3 word_doc.py build plan.json output.docx [--images DIR]

The plan is a list of blocks. Types:
  cover, contents, divider, heading, text, pullout, takeaways, stats, sidebar, quote,
  table, image, case_study, process, page_break, back_cover
"""
import json, os, sys, re, datetime, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import kit
from kit import *
from docx import Document


def read_docx(path):
    """Headings, paragraphs, bullets (with bold lead-ins) and tables, in order."""
    import docx
    from docx.table import Table
    from docx.text.paragraph import Paragraph
    d = docx.Document(path)
    out = {'title': '', 'subtitle': '', 'sections': []}
    cur = None
    for el in d.element.body.iterchildren():
        tag = el.tag.split('}')[1]
        if tag == 'tbl':
            rows = [[c.text.strip() for c in r.cells] for r in Table(el, d).rows]
            if cur is None:
                cur = {'title': 'Introduction', 'items': []}; out['sections'].append(cur)
            cur['items'].append(['t', rows]); continue
        if tag != 'p':
            continue
        p = Paragraph(el, d); txt = p.text.strip()
        if not txt:
            continue
        st = (p.style.name or '').lower()
        if st == 'title' and not out['title']:
            out['title'] = txt; continue
        if st.startswith('heading 1'):
            cur = {'title': re.sub(r'^\d+[.)]\s*', '', txt), 'items': []}; out['sections'].append(cur); continue
        if cur is None and out['title'] and not out['subtitle'] and not st.startswith('heading'):
            out['subtitle'] = txt; continue
        if cur is None:
            cur = {'title': 'Introduction', 'items': []}; out['sections'].append(cur)
        if st.startswith('heading'):
            cur['items'].append(['h', txt]); continue
        if 'list' in st or (p._p.pPr is not None and p._p.pPr.numPr is not None):
            lead = ''
            if p.runs and p.runs[0].bold and len(p.runs) > 1:
                lead = p.runs[0].text.strip().rstrip(':').strip(); txt = ''.join(r.text for r in p.runs[1:]).strip()
            cur['items'].append(['b', txt, lead]); continue
        cur['items'].append(['p', txt])
    return out


def split_title(t):
    """Two-tone heading: first word(s) Medium, the rest Light."""
    w = t.split()
    if len(w) <= 2:
        return t, ''
    k = 1 if len(w) <= 4 else 2
    return ' '.join(w[:k]), ' '.join(w[k:])


def plan(doc, doc_type='Document', short=None):
    short = short or doc['title']
    ts, tl = split_title(doc['title'])
    blocks = [{'type': 'cover', 'title': ts, 'title_light': tl, 'subtitle': doc['subtitle'], 'doc_type': doc_type,
               'prepared': f"Continu  |  {datetime.date.today():%B %Y}"}]
    secs = doc['sections']
    if len(secs) >= 4:
        blocks.append({'type': 'contents', 'entries': [s['title'] for s in secs]})
    for i, s in enumerate(secs):
        its = s['items']; sf = ''
        if its and its[0][0] == 'p' and len(its[0][1].split()) <= 45 and len(its) > 1:
            sf = its[0][1]; its = its[1:]
        a, b = split_title(s['title'])
        blocks.append({'type': 'opener', 'label': f"{i+1:02d}  {short}", 'title': a, 'title_light': b,
                       'standfirst': sf, 'new_page': i == 0})
        run_ = []
        for it in its:
            if it[0] == 't':
                if run_: blocks.append({'type': 'text', 'items': run_}); run_ = []
                blocks.append({'type': 'table', 'rows': it[1]})
            else:
                run_.append(it)
        if run_: blocks.append({'type': 'text', 'items': run_})
    blocks.append({'type': 'back_cover', 'heading': 'Taking back control starts here',
                   'lines': ['continuenergy.com', '+44 (0)28 9045 4900']})
    return blocks


def build(blocks, out, images=None):
    tmp = tempfile.mkdtemp()
    default_img = (images or {}).get('default') or os.path.join(kit.ASSET, 'photo_default.jpg')
    d = setup(Document()); blank_header_footer(d.sections[0])
    running = next((b['title'] + (' ' + b.get('title_light', '') if b.get('title_light') else '') for b in blocks if b['type'] == 'cover'), 'Continu')
    started = False; n = 0; prev = None
    for b in blocks:
        n += 1; t = b['type']
        prev, cur = (blocks[n - 2]['type'] if n > 1 else None), t
        img = b.get('image') or default_img
        if t == 'cover':
            cover(d, b['title'], b.get('title_light', ''), b.get('subtitle', ''), b.get('doc_type', 'Document'), b.get('prepared', ''), img, tmp)
            continue
        if t in ('divider', 'back_cover', 'contents', 'grey_page'):
            s = new_page_section(d)
            if t in ('divider', 'back_cover'):
                blank_header_footer(s); started = False
                if t == 'divider': divider(d, b['number'], b['title'], b.get('intro', ''), img, tmp)
                else: back_cover(d, b.get('heading', ''), b.get('lines', []), img, tmp)
            else:
                interior_header_footer(d, s, running); started = True
                if t == 'contents':
                    contents_page(d, b['entries'])
                    new_page_section(d)   # contents stands alone; the next page starts fresh
                else:
                    p = para(d, after=0); page_tint(p, GREY)
            continue
        if not started:
            s = new_page_section(d); interior_header_footer(d, s, running); started = True
        elif b.get('new_page') and prev not in ('contents',):
            d.add_paragraph().add_run().add_break(WD_BREAK.PAGE)
        if t == 'opener':
            if not b.get('new_page') and not b.get('fill'):
                vgap(d, 8)
            page_opener(d, b.get('label'), b['title'], b.get('title_light', ''), b.get('standfirst', ''),
                        b.get('image'), tmp, f'hero{n}', {'grey': GREY, 'navy': NAVY}.get(b.get('fill')))
        elif t == 'text':
            ins = {}
            for k, v in (b.get('pullouts') or {}).items():
                ins[int(k)] = (lambda v=v: (lambda dd: pullout(dd, v[0], v[1], v[2] if len(v) > 2 else True)))()
            body_columns(d, [tuple(x) for x in b['items']], b.get('cols', 2), ins)
        elif t == 'pullout':
            pullout(d, b.get('label', ''), b['text'], b.get('dark', True), TEXT_W)
        elif t == 'takeaways':
            takeaways(d, [tuple(x) for x in b['points']], b.get('title', 'Key takeaways'))
        elif t == 'stats':
            stats(d, [tuple(x) for x in b['items']])
        elif t == 'sidebar':
            sidebar(d, [tuple(x) for x in b['items']], b.get('label', 'At a glance'), b.get('figure', ''), b.get('caption', ''), b.get('facts', []))
        elif t == 'quote':
            quote_panel(d, b['text'], b.get('who', ''))
        elif t == 'table':
            data_table(d, b['rows'], b.get('total_row', False))
        elif t == 'image':
            figure(d, img, b.get('caption', ''), tmp, f'fig{n}', b.get('ratio', 0.42))
        elif t == 'case_study':
            case_study(d, b['client'], b['title'], b.get('title_light', ''), b['challenge'], b['solution'],
                       [tuple(x) for x in b.get('results', [])], img, tmp)
        elif t == 'process':
            process(d, [tuple(x) for x in b['steps']], b.get('title'))
        elif t == 'page_break':
            d.add_paragraph().add_run().add_break(WD_BREAK.PAGE)
    d.save(out)


if __name__ == '__main__':
    a = sys.argv
    if a[1] == 'plan':
        dt = a[a.index('--doc-type') + 1] if '--doc-type' in a else 'Document'
        sh = a[a.index('--short') + 1] if '--short' in a else None
        pl = plan(read_docx(a[2]), dt, sh)
        json.dump(pl, open(a[3], 'w'), indent=1, ensure_ascii=False)
        for i, b in enumerate(pl, 1):
            print(f"{i:2d}. {b['type']:<11} {b.get('title', '')}")
    else:
        build(json.load(open(a[2])), a[3])
        print('built', a[3])
