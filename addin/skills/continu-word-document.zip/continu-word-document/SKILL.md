---
name: continu-word-document
description: Create or rebrand a Word document in the Continu brand from the Continu Word component library – covers, navy section dividers with the brand ring, text pages, pull-out boxes, grey bands, big numbers, sidebars, quotes, tables, images, case studies, process steps and back covers. Use when someone attaches a Word document to tidy, rebrand or turn into a report, or asks for a branded Word document from notes.
---

# Continu Word document

Builds branded A4 Word documents from a **kit of parts**: the Continu Word component
library (`assets/Continu_Word_Component_Library.docx`). Every part in the library is wrapped
in a content control tagged `CO_W_<NAME>`. The skill picks parts, fills them with the
content it was given, and leaves out what isn't needed – the same way the PowerPoint skills
use the slide library.

## Brand rules (never break these)
- Pages are white. Colour comes from **navy** (#324E64) and **light grey** (#E6EAE4): pull-out boxes
  inside the columns, edge-to-edge bands (openers, quotes, takeaways) and whole-page grey tints
  (contents). Lime (#B5EB03) only for small labels on navy and the Endless Energy device.
- Grid: A4, 18 mm margins, two columns with an 8 mm gutter for body text. Bands only in one-column
  parts of the page.
- Type: headings two-tone (a Medium phrase, then Light), body Effra 9/13.5, exact leading,
  kerning on. Labels in sentence case, never letter-spaced capitals.
- Navy full pages only for the **cover**, **section dividers** and **back cover**. Each has the
  brand's thick ring with a photo inside and the Endless Energy device. Never use thin circle
  outlines – they are not part of the brand.
- Font names exactly as Continu's PowerPoint template: `Effra`, `EFFRA-LIGHT`, `Effra Medium`
  ("Effra Light" falls back to the italic on Mac). Use the styles; never shrink text to fit.
- Curved corners on photos. British English.

## The parts

| Tag | Part | Use it for |
|---|---|---|
| CO_W_COVER | Cover (navy, brand ring) | First page |
| CO_W_CONTENTS | Contents (grey page) | Four or more sections |
| CO_W_DIVIDER | Section divider (navy, brand ring) | Major parts of long documents (6+ sections) |
| CO_W_OPENER / _GREY / _NAVY | Page opener: white, grey band, navy band | Start of every section; use bands to vary the rhythm |
| CO_W_OPENER_PHOTO | Opener with photo (curved corners) | Sections that need a picture |
| CO_W_TEXT | Two-column text, pull-outs in the flow | Body text, subheads, bullets |
| CO_W_PULLOUT_GREY | Grey pull-out | Softer asides and definitions |
| CO_W_QUOTE | Quote band (edge to edge) | Quotes, one-line philosophies |
| CO_W_TAKEAWAYS | Takeaways band (edge to edge, white cards) | Three conclusions or groups |
| CO_W_STATS | Big numbers | Two to four headline figures from the document |
| CO_W_SIDEBAR | Text with "at a glance" box | One key figure plus short facts |
| CO_W_PROCESS | Numbered step cards | Processes, method statements |
| CO_W_TABLE | Continu Table | Any table |
| CO_W_IMAGE | Photo and caption | Pictures |
| CO_W_CASE_STUDY | Case study | Client, challenge, solution, results |
| CO_W_BACK_COVER | Back cover (navy) | Contact details |

## How to work

1. **Ask first** (clickable question if available): *Rebrand this document as it is* (keep the
   author's words and order) or *Rework it into a report* (same content, more visual parts).
   Ask for anything missing: document type, who it's for, photos to use.
2. **Plan** the document as a list of parts and show it to the person (part – heading).
   Every Heading 1 becomes a text page; tables become CO_W_TABLE.
3. **Add rhythm** – a run of plain text pages is the thing to avoid. Roughly every page or two,
   use one of: a pull-out, a grey band (takeaways or quote), big numbers, a sidebar, an image.
   Only use content that is already in the document: never invent figures, quotes or claims.
   A short line that sums up a section may be written from that section's own words.
4. **Build**, then check every page: no blank pages, no part split awkwardly over a page,
   headings not left at the bottom of a page.

### Route A – with code (Claude, ChatGPT with code execution)

```bash
python3 scripts/word_doc.py plan  input.docx plan.json --doc-type "INTERNAL GUIDE" --short "Customer success playbook"
# review plan.json: standfirsts, pull-outs, bands, stats, images (see the block types in word_doc.py)
python3 scripts/word_doc.py build plan.json output.docx
```
Render to PDF and look at every page before handing it over.

### Route B – inside Word (Claude for Word / ChatGPT for Word)
1. Open the component library and save it as the new document.
2. For each part in the plan, find it with `context.document.contentControls.getByTag("CO_W_...")`.
   To use a part twice, copy it with `getOoxml()` and `insertOoxml(..., "After")` on the part it
   should follow.
3. Replace the placeholder text inside each part (`insertText(..., "Replace")` on the paragraph
   ranges, keeping their styles). Replace photos with `insertInlinePictureFromBase64` when given one.
4. Delete every part that wasn't used, then the "How to use" page.

## RAMS (risk assessment and method statements)
A RAMS document is built from the same kit: cover, job details (CO_W_TABLE), PPE and hazards
(CO_W_TABLE with tick columns), method of work (CO_W_PROCESS), sign-off table. The job details
come from a screenshot of the work order (Dynamics now, Simpro later). The exact layout will be
set from Continu's own RAMS templates.
